public interface DodawanieBroni {
    void dodaj();
}

public class LukKrotki implements DodawanieBroni {
    @Override
    public void dodaj(){
        System.out.println("LukKrotki");
    }
}

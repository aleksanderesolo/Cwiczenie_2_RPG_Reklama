public class Lucznik extends Postac{
    public Lucznik(){}
    public Lucznik(DodawanieBroni dodawanieBroni){
        super(dodawanieBroni);
    }
}

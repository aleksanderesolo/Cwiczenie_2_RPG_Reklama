public class Armata implements DodawanieBroni{
    @Override
    public void dodaj() {
        System.out.println("Armata");
    }
}

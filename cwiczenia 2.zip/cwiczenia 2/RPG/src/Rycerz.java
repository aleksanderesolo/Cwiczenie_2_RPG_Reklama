public class Rycerz extends Postac{
    public Rycerz(){}
    public Rycerz(DodawanieBroni dodawanieBroni){
        super(dodawanieBroni);
    }
}

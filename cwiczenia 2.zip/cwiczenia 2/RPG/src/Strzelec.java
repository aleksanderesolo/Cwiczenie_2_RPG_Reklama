public class Strzelec extends Postac{
    public Strzelec(){}
    public Strzelec(DodawanieBroni dodawanieBroni){
        super(dodawanieBroni);
    }
}

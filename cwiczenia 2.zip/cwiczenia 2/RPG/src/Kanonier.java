public class Kanonier extends Postac{
    public Kanonier(){}
    public Kanonier(DodawanieBroni dodawanieBroni){
        super(dodawanieBroni);
    }
}

public class Miecz implements DodawanieBroni{
    @Override
    public void dodaj() { System.out.println("Miecz"); }
}

public class PocztaGlosowa implements WyborSposobuDostawy{
    @Override
    public void wybierzDostawe() { System.out.println("poczta glosowa");}
}

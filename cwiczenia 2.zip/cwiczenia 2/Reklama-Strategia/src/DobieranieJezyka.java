public interface DobieranieJezyka {
    void dobierzJezyk();
}

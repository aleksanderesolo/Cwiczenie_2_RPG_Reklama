public interface WyborSposobuDostawy {
    void wybierzDostawe();
}

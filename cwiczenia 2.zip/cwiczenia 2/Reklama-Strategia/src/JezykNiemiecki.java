public class JezykNiemiecki implements DobieranieJezyka{
    @Override
    public void dobierzJezyk() { System.out.println("po niemiecku"); }
}

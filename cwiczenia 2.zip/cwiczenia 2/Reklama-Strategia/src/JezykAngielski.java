public class JezykAngielski implements DobieranieJezyka{
    @Override
    public void dobierzJezyk() { System.out.println("po angielsku"); }
}

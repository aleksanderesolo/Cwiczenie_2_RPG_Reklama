public class SMS implements WyborSposobuDostawy{
    @Override
    public void wybierzDostawe() { System.out.println("SMS'em");}
}

public class JezykHiszpanski implements DobieranieJezyka{
    @Override
    public void dobierzJezyk() { System.out.println("po hiszpansku");}
}

public class ListElektroniczny implements WyborSposobuDostawy{
    @Override
    public void wybierzDostawe() { System.out.println("listem elektronicznym");}
}
